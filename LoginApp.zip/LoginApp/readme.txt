#Node-->Login & Registration App
###A basic account management system built in Node.js with the following features:

1)New User Account Creation
2)Secure Password 
3)Session Tracking for Logged-In Users
4)Local Cookie Storage for Returning Users
5)BcryptJs use for User Password Encryption 


###Node-Login is built on top of the following libraries :

1)Node.js - Application Server
2)Express.js - Node.js Web Framework
3)MongoDb - Database Storage
4)Handlebar - HTML Templating Engine
5)NodeMailer - Node.js > SMTP Server Middleware
6)Twitter Bootstrap - UI Component & Layout Library 


##Installation & Setup

1)Install Node.js & MongoDB if you haven't already.
2)Clone this repository and install its dependencies.
  >cd LoginApp
  >npm install
3)In a separate shell start the MongoDB daemon.
  >mongod
4)If use the ubuntu than add the (db) file inside the LoginApp & run the command
  >mongod --dbapth ./db (to run the mongodb server)
5)From within the LoginApp directory, start the server.
  >node app.js
6)Open a browser window and navigate to: http://localhost:3000
